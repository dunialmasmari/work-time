<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class jobApplyer extends Model
{
    //
}
